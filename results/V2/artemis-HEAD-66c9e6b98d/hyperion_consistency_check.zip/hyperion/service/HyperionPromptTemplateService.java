package de.tum.cit.aet.artemis.hyperion.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

import de.tum.cit.aet.artemis.hyperion.config.HyperionEnabled;

@Service
@Lazy
@Conditional(HyperionEnabled.class)
public class HyperionPromptTemplateService {

    /**
     * Render the template at the given classpath resource path with the provided variables.
     * <p>
     * Supporting placeholders of the form {{var}}
     *
     * @param resourcePath classpath to the template resource
     * @param variables    map of variables used during rendering
     * @return the rendered string
     */
    public String render(String resourcePath, Map<String, String> variables) {
        try {
            var resource = new ClassPathResource(resourcePath);
            String rendered = StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
            for (var entry : variables.entrySet()) {
                rendered = rendered.replace("{{" + entry.getKey() + "}}", entry.getValue());
            }
            return rendered;
        }
        catch (IOException e) {
            throw new RuntimeException("Failed to load template: " + resourcePath, e);
        }
    }

    /**
     * Render the template at the given classpath resource path with the provided variables.
     * <p>
     * Supporting placeholders of the form {{var}}
     *
     * @param resourcePath classpath to the template resource
     * @param variables    map of variables used during rendering
     * @return the rendered string
     */
    public String renderObject(String resourcePath, Map<String, Object> variables) {
        try {
            var resource = new ClassPathResource(resourcePath);
            String rendered = StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
            for (var entry : variables.entrySet()) {
                rendered = rendered.replace("{{" + entry.getKey() + "}}", entry.getValue().toString());
            }
            return rendered;
        }
        catch (IOException e) {
            throw new RuntimeException("Failed to load template: " + resourcePath, e);
        }
    }
}
