package de.tum.cit.aet.artemis.hyperion.dto;

import java.time.Instant;
import java.util.List;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO for consistency check responses.
 * The {@code issues} field uses a bare {@code @JsonInclude} (no explicit value = ALWAYS) to ensure an empty list
 * is always serialized as {@code "issues": []}, allowing evaluation scripts to correctly count false negatives.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Response containing consistency check results")
public record ConsistencyCheckResponseDTO(

        @NotNull @Schema(description = "Timestamp of the response generation") Instant timestamp,

        @JsonInclude @NotNull @Schema(description = "List of consistency issues found") List<ConsistencyIssueDTO> issues,

        @Schema(description = "Execution timing details") TimingDTO timing,

        @Schema(description = "Token usage statistics") TokensDTO tokens,

        @Schema(description = "Costs statistics") CostsDTO costs) {
}
